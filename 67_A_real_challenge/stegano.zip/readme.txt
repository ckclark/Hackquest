This is the new high quality HackQuest stegano program.
It can put any message inside a BMP, and extract it.

Unfortunately it has two problems.

1. Its a linux executable compiled under Slackware.
2. Its only a trial version.

Have fun with it though.

SkyFlash